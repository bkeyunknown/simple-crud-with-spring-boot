package com.app.kuliah.dataMahasiswa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataMahasiswaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataMahasiswaApplication.class, args);
	}

}
